package com.agsi.app

import android.content.Context
import android.webkit.JavascriptInterface

/**
 * JEMBATAN JS `window.AgsiNative` — kontrak dengan src/lib/push-client.ts.
 *
 * Metode WAJIB:
 *   getFcmToken(): String — dipanggil PushBridge.tsx setelah pengguna login
 *   agar token terdaftar dengan sesi (platform "android", terikat role).
 *
 * Metode opsional:
 *   getAppVersion(): String — bisa dipakai halaman untuk info versi.
 *
 * Keamanan: bridge hanya dipasang pada WebView dengan allowlist domain AGSI
 * dan tidak mengekspos data rahasia — token FCM adalah identifier perangkat
 * yang memang dikirim ke backend milik AGSI sendiri.
 */
class AgsiNativeBridge(private val appContext: Context) {

    @JavascriptInterface
    fun getFcmToken(): String = PushRegistrar.cachedToken(appContext)

    @JavascriptInterface
    fun getAppVersion(): String = BuildConfig.VERSION_NAME
}
